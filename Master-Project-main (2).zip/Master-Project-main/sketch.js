function setup() {
  createCanvas(windowWidth, windowHeight);
  

}

function draw() {
  fill(0);
  textSize(40);
  textAlign(CENTER,CENTER);
  
  textSize(16);
  //text("Trong Huey Than", width / 2, height / 7 + 20 + 32);
  //text("Nyang Lynn Kyaw", width / 2, height / 7 + 20 + 50);
  //text("Datth Eragam", width / 2, height / 7 + 20 + 70);
  //text("Divyank Malik", width / 2, height / 7 + 20 + 90);
  //text("Benjamin Pedraza", width / 2, height / 7 + 20 + 110);
}